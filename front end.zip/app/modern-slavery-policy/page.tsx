import Modern from "./ModernSlaveryPolicy";



export default function page(){


    return(
        <>
        
<Modern/>
        </>
    );
}